@extends('frontend.layout')
@section('title', 'My Bookings')

@section('content')
<div id="main-contents">
    <div class="full-wdith grey">
        <div class="wrap" style="max-width: 1000px;">
            <div class="row nogap">
                <div class="white d-gap-t shadow-box" style="margin-bottom:30px; min-height: 400px;">

                    <div class="sd-12 h-pad pvt-orange">
                        <h2 style="font-size:22px; color:#fff; padding: 15px 0;">
                            <i class="fa-list-ul"></i> My Bookings
                        </h2>
                    </div>

                    <div class="sd-12 pad">
                        @if($bookings->isEmpty())
                            <div style="text-align:center; padding:50px 0;">
                                <i class="fa-calendar-o" style="font-size:60px; color:#ddd; margin-bottom:20px; display:block;"></i>
                                <h3 style="color:#999;">You have no bookings yet.</h3>
                                <a href="/{{ $lang }}/" class="btn blue" style="margin-top:20px;">Explore Tours</a>
                            </div>
                        @else
                            <div class="responsive-table">
                                <table class="table" style="width:100%; border-collapse: collapse;">
                                    <thead>
                                        <tr style="background:#f5f5f5; border-bottom:2px solid #eee;">
                                            <th style="padding:12px; text-align:left;">Booking ID</th>
                                            <th style="padding:12px; text-align:left;">Tour Name</th>
                                            <th style="padding:12px; text-align:left;">Travel Date</th>
                                            <th style="padding:12px; text-align:left;">Status</th>
                                            <th style="padding:12px; text-align:left;">Invoice</th>
                                            <th style="padding:12px; text-align:center;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($bookings as $booking)
                                            <tr style="border-bottom:1px solid #eee;">
                                                <td style="padding:12px;">#{{ $booking->id }}</td>
                                                <td style="padding:12px;">
                                                    @if($booking->tour && $booking->tour->contents->first())
                                                        <strong>{{ $booking->tour->contents->first()->title }}</strong>
                                                    @else
                                                        Booking #{{ $booking->id }}
                                                    @endif
                                                </td>
                                                <td style="padding:12px;">{{ $booking->travel_date }}</td>
                                                <td style="padding:12px;">
                                                    @php
                                                        $statusClass = 'grey';
                                                        $statusLabel = $booking->trip_status;
                                                        if($booking->trip_status == 'confirmed' || $booking->trip_status == 'con') { $statusClass = 'success'; $statusLabel = 'Confirmed'; }
                                                        elseif($booking->trip_status == 'pending') { $statusClass = 'warning'; $statusLabel = 'Pending'; }
                                                        elseif($booking->trip_status == 'cancelled' || $booking->trip_status == 'can') { $statusClass = 'error'; $statusLabel = 'Cancelled'; }
                                                    @endphp
                                                    <span class="label {{ $statusClass }}" style="font-size:11px; padding:2px 8px;">{{ strtoupper($statusLabel) }}</span>
                                                </td>
                                                <td style="padding:12px;">
                                                    @if($booking->invoice)
                                                        @php
                                                            $invStatusClass = 'grey';
                                                            if($booking->invoice->status == 'p') $invStatusClass = 'success';
                                                            elseif($booking->invoice->status == 'u') $invStatusClass = 'error';
                                                            elseif($booking->invoice->status == 'pp') $invStatusClass = 'warning';
                                                        @endphp
                                                        <span class="{{ $invStatusClass }}-text" style="font-weight:bold;">
                                                            {{ number_format($booking->invoice->total, 2) }} {{ $activeCurrency }}
                                                        </span>
                                                        <span style="font-size:10px; color:#999; display:block;">({{ $booking->invoice->status == 'p' ? 'Paid' : 'Unpaid' }})</span>
                                                    @else
                                                        N/A
                                                    @endif
                                                </td>
                                                <td style="padding:12px; text-align:center;">
                                                    @if($booking->invoice)
                                                        <a href="/{{ $lang }}/invoice/{{ $booking->invoice->id }}/" class="btn {{ $booking->invoice->status == 'u' ? 'blue' : 'green' }}" style="padding:4px 12px; font-size:12px;">
                                                            <i class="fa-file-text-o"></i> {{ $booking->invoice->status == 'u' ? 'Pay Now' : 'View Invoice' }}
                                                        </a>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
