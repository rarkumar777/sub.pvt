@extends('frontend.layout')

@section('title', $page->title ?? 'Page')
@section('description', $page->meta_desc ?? '')
@section('keywords', $page->meta_key ?? '')

@section('content')
<div class="body-wrap" style="padding-top: 80px;">
    <div class="wrap">
        <div class="row">
            <div class="sd-12 nopad">
                <div class="row">
                    <div class="d-pad">
                        <h1>{{ $page->title ?? '' }}</h1>
                        <div class="pad">
                            {!! $pageContent ?? '' !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
