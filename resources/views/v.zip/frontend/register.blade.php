@extends('frontend.layout')
@section('title', 'Create My Account')

@section('content')
<div id="main-contents">
    <div class="full-wdith grey">
        <div class="wrap">
            <div class="row nogap">
                <div class="white d-gap-t shadow-box" style="margin-bottom:30px;">

                    <div class="sd-12 h-pad">
                        <h2 style="font-size:22px; color:#333; border-bottom:1px solid #ddd; padding-bottom:10px;">
                            <i class="fa-edit"></i> Create My Account
                        </h2>
                    </div>

                    @if($errors->any())
                        @foreach($errors->all() as $error)
                            <div class="sd-12 pad" style="background:#f2dede; color:#a94442; border:1px solid #ebccd1; margin-bottom:8px; border-radius:3px;">
                                <i class="fa-close"></i> {{ $error }}
                            </div>
                        @endforeach
                    @endif

                    <div class="sd-12 pad">
                        <form method="POST" action="/{{ $lang }}/users/register/" enctype="multipart/form-data">
                            @csrf

                            {{-- First Name / Last Name --}}
                            <div class="row cell">
                                <div class="md-2"><label>First Name</label></div>
                                <div class="md-4">
                                    <input type="text" name="first_name" value="{{ old('first_name') }}" class="full-width" required>
                                    <span style="color:red;">*</span>
                                </div>
                                <div class="md-2"><label>Last Name</label></div>
                                <div class="md-4">
                                    <input type="text" name="last_name" value="{{ old('last_name') }}" class="full-width" required>
                                    <span style="color:red;">*</span>
                                </div>
                            </div>

                            {{-- Email / URL --}}
                            <div class="row cell">
                                <div class="md-2"><label>E-mail</label></div>
                                <div class="md-4">
                                    <input type="email" name="email" value="{{ old('email') }}" class="full-width" required>
                                    <span style="color:red;">*</span>
                                </div>
                                <div class="md-2"><label>URL</label></div>
                                <div class="md-4">
                                    <input type="text" name="url" value="{{ old('url') }}" class="full-width">
                                </div>
                            </div>

                            {{-- Country / City --}}
                            <div class="row cell">
                                <div class="md-2"><label>Country</label></div>
                                <div class="md-4">
                                    <select name="country" class="full-width">
                                        @foreach($countries as $c)
                                            <option value="{{ $c->name }}" {{ old('country') == $c->name ? 'selected' : '' }}>{{ $c->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="md-2"><label>City</label></div>
                                <div class="md-4">
                                    <input type="text" name="city" value="{{ old('city') }}" class="full-width" placeholder="City">
                                </div>
                            </div>

                            {{-- Company / Mobile --}}
                            <div class="row cell">
                                <div class="md-2"><label>Company Name</label></div>
                                <div class="md-4">
                                    <input type="text" name="company" value="{{ old('company') }}" class="full-width">
                                </div>
                                <div class="md-2"><label>Mobile</label></div>
                                <div class="md-4">
                                    <input type="text" name="mobile" value="{{ old('mobile') }}" class="full-width">
                                </div>
                            </div>

                            {{-- Telephone / Fax --}}
                            <div class="row cell">
                                <div class="md-2"><label>Telephone</label></div>
                                <div class="md-4">
                                    <input type="text" name="telephone" value="{{ old('telephone') }}" class="full-width">
                                </div>
                                <div class="md-2"><label>Fax</label></div>
                                <div class="md-4">
                                    <input type="text" name="fax" value="{{ old('fax') }}" class="full-width">
                                </div>
                            </div>

                            {{-- Address / Birth Date --}}
                            <div class="row cell">
                                <div class="md-2"><label>Address</label></div>
                                <div class="md-4">
                                    <input type="text" name="address" value="{{ old('address') }}" class="full-width">
                                </div>
                                <div class="md-2"><label>Birth Date</label></div>
                                <div class="md-4">
                                    <input type="date" name="birth_day" value="{{ old('birth_day') }}" class="full-width" placeholder="YYYY-DD-MM">
                                </div>
                            </div>

                            {{-- Gender / Avatar --}}
                            <div class="row cell">
                                <div class="md-2"><label>Gender</label></div>
                                <div class="md-4">
                                    <select name="gender" class="full-width">
                                        <option value="male" {{ old('gender') == 'male' ? 'selected' : '' }}>Male</option>
                                        <option value="female" {{ old('gender') == 'female' ? 'selected' : '' }}>Female</option>
                                    </select>
                                </div>
                                <div class="md-2"><label>Avatar</label></div>
                                <div class="md-4">
                                    <input type="file" name="avatar" accept="image/*">
                                </div>
                            </div>

                            {{-- Password / Retype --}}
                            <div class="row cell">
                                <div class="md-2"><label>Password</label></div>
                                <div class="md-4">
                                    <input type="password" name="password" class="full-width" required>
                                    <span style="color:red;">*</span>
                                </div>
                                <div class="md-2"><label>Retype Password</label></div>
                                <div class="md-4">
                                    <input type="password" name="retype_password" class="full-width" required>
                                    <span style="color:red;">*</span>
                                </div>
                            </div>

                            <hr style="border-color:#eee; margin:15px 0;">

                            {{-- Captcha --}}
                            <div class="row cell">
                                <div class="md-2"><label>Robot Verifications</label></div>
                                <div class="md-4">
                                    <div style="display:flex; align-items:stretch;">
                                        <div style="background:#d9edf7; border:1px solid #bce8f1; border-radius:3px 0 0 3px; min-width:60px; display:flex; align-items:center; justify-content:center; padding:0 10px;">
                                            <span style="font-weight:700; font-size:16px; color:#31708f; font-style:italic; letter-spacing:1px; user-select:none;">{{ $captchaCode }}</span>
                                        </div>
                                        <input type="text" name="captcha"
                                               style="flex:1; height:36px; padding:0 10px; background:#f5f5f5; border:1px solid #c0cfe0; border-left:none; border-radius:0 3px 3px 0; font-size:14px;"
                                               placeholder="code from the left blue box..." required>
                                    </div>
                                </div>
                            </div>

                            <hr style="border-color:#eee; margin:15px 0;">

                            {{-- Submit --}}
                            <div class="row cell" style="text-align:center;">
                                <button type="submit" class="btn blue" style="padding:10px 35px; font-size:16px;">
                                    <i class="fa-check"></i> Create My Account
                                </button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
